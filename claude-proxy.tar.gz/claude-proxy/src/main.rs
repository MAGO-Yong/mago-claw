use bytes::{Bytes, BytesMut};
use clap::Parser;
use http_body_util::{BodyExt, Full, StreamBody};
use hyper::body::{Frame, Incoming};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::{Request, Response};
use hyper_tls::HttpsConnector;
use hyper_util::client::legacy::Client;
use hyper_util::rt::TokioExecutor;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use tokio::net::TcpListener;
use tokio::sync::mpsc;

// ── codewiz telemetry endpoints ──
const METRICS_API: &str = "http://codewiz.devops.xiaohongshu.com/complete/metrics/v1";
const METRICS_EXTENDED_API: &str = "http://codewiz.devops.xiaohongshu.com/complete/api/v1/metrics-extended/batch";
const LOG_API: &str = "http://codewiz.devops.xiaohongshu.com/complete/api/v1/logs/batch";
const CODEWIZ_VERSION: &str = "0.1.37";

// ── pseudo-random state ──
static RNG_STATE: AtomicU64 = AtomicU64::new(0);

fn next_rand() -> u64 {
    loop {
        let old = RNG_STATE.load(Ordering::Relaxed);
        let new = old.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        if RNG_STATE.compare_exchange(old, new, Ordering::Relaxed, Ordering::Relaxed).is_ok() {
            return new;
        }
    }
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}

fn uuid_v4() -> String {
    let r1 = next_rand();
    let r2 = next_rand();
    format!(
        "{:08x}-{:04x}-4{:03x}-{:04x}-{:012x}",
        (r1 >> 32) as u32,
        (r1 >> 16) as u16 & 0xffff,
        r1 as u16 & 0x0fff,
        (r2 >> 48) as u16 & 0x3fff | 0x8000,
        r2 & 0xffffffffffff
    )
}

fn call_id() -> String {
    let r = next_rand();
    format!("call_{:016x}", r)
}

// ── CLI args ──
#[derive(Parser, Clone)]
#[command(name = "claude-proxy", about = "Anthropic API proxy for codewiz backend")]
struct Args {
    /// SSO token (auto-detected from auth.json if omitted)
    #[arg(long)]
    sso_token: Option<String>,
    /// User email (auto-detected from auth.json if omitted)
    #[arg(long)]
    email: Option<String>,
    #[arg(long, default_value = "8089")]
    port: u16,
    #[arg(long, default_value = "https://codewiz.devops.xiaohongshu.com/llmadapter/v3/claude")]
    upstream: String,
    #[arg(long, default_value = "common-internal-access-token-prod")]
    sso_token_key: String,
    /// Disable fake metrics reporting
    #[arg(long)]
    no_metrics: bool,
}

/// Parsed credentials from auth.json
struct Credentials {
    sso_token: String,
    sso_token_key: String,
    email: String,
}

fn auto_detect_credentials() -> Option<Credentials> {
    let token_b64 = read_token_from_auth_json()?;
    let decoded = base64_decode(&token_b64);
    let v: Value = serde_json::from_slice(&decoded).ok()?;
    let sso_token = v.get("ssoAccessToken")?.as_str()?.to_string();
    let sso_token_key = v.get("ssoAccessTokenKey")?.as_str().unwrap_or("common-internal-access-token-prod").to_string();
    let email = v.get("email")?.as_str()?.to_string();
    Some(Credentials { sso_token, sso_token_key, email })
}

type HttpsClient = Client<HttpsConnector<hyper_util::client::legacy::connect::HttpConnector>, Full<Bytes>>;

/// Per-session state shared across requests, keeps session/conversation IDs stable.
struct SessionState {
    session_id: String,
    conversation_id: String,
    request_count: AtomicU64,
}

impl SessionState {
    fn new() -> Self {
        Self {
            session_id: uuid_v4(),
            conversation_id: uuid_v4(),
            request_count: AtomicU64::new(0),
        }
    }
    fn bump(&self) -> u64 {
        self.request_count.fetch_add(1, Ordering::Relaxed)
    }
    /// Rotate conversation_id periodically (every ~10 requests) to mimic new user turns.
    fn maybe_rotate_conversation(&mut self) {
        let n = self.request_count.load(Ordering::Relaxed);
        if n > 0 && n % 10 == 0 {
            self.conversation_id = uuid_v4();
        }
    }
}

struct ProxyState {
    client: HttpsClient,
    upstream_authority: String,
    upstream_path_prefix: String,
    sso_token: String,
    sso_token_key: String,
    email: String,
    no_metrics: bool,
    model_map: HashMap<&'static str, &'static str>,
    user_info: Value,
    session: tokio::sync::Mutex<SessionState>,
}

fn build_model_map() -> HashMap<&'static str, &'static str> {
    let mut m = HashMap::new();
    m.insert("claude-sonnet-4-6", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-6-20250627", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-5", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-5-20250514", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-5-20250929", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-20250514", "claude-4.6-sonnet-google");
    m.insert("claude-opus-4-6", "claude-4.6-opus-google");
    m.insert("claude-opus-4-6-20250627", "claude-4.6-opus-google");
    m.insert("claude-opus-4-0-20250515", "claude-4.6-opus-google");
    m.insert("claude-haiku-4-5", "claude-4.5-haiku-google");
    m.insert("claude-haiku-4-5-20251001", "claude-4.5-haiku-google");
    m.insert("claude-sonnet-4-0", "claude-4.6-sonnet-google");
    m.insert("claude-sonnet-4-0-20250514", "claude-4.6-sonnet-google");
    m
}

/// Decode base64 token to extract user info for metrics.
fn extract_user_info(token: &str) -> Value {
    let decoded = base64_decode(token);
    if let Ok(v) = serde_json::from_slice::<Value>(&decoded) {
        json!({
            "name": v.get("name").and_then(|v| v.as_str()).unwrap_or(""),
            "email": v.get("email").and_then(|v| v.as_str()).unwrap_or(""),
            "userId": v.get("userId").and_then(|v| v.as_str()).unwrap_or(""),
            "accountNo": v.get("accountNo").and_then(|v| v.as_str()).unwrap_or(""),
            "userNameAlias": v.get("userNameAlias").and_then(|v| v.as_str()).unwrap_or(""),
        })
    } else {
        json!({})
    }
}

fn base64_decode(input: &str) -> Vec<u8> {
    // simple base64 decode without external crate
    let table = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut buf = Vec::new();
    let mut bits: u32 = 0;
    let mut n_bits = 0;
    for &b in input.as_bytes() {
        let val = if b == b'=' { break } else if let Some(pos) = table.iter().position(|&t| t == b) { pos as u32 } else { continue };
        bits = (bits << 6) | val;
        n_bits += 6;
        if n_bits >= 8 {
            n_bits -= 8;
            buf.push((bits >> n_bits) as u8);
            bits &= (1 << n_bits) - 1;
        }
    }
    buf
}

// ── Header filtering ──
const ALLOWED_BETA_PREFIXES: &[&str] = &[
    "prompt-caching-2", "max-tokens-", "output-", "token-counting-",
    "interleaved-thinking-", "extended-cache-ttl-",
];

fn filter_beta_header(value: &str) -> Option<String> {
    let filtered: Vec<&str> = value.split(',').map(|v| v.trim())
        .filter(|v| !v.is_empty())
        .filter(|v| ALLOWED_BETA_PREFIXES.iter().any(|p| v.starts_with(p)))
        .collect();
    if filtered.is_empty() { None } else { Some(filtered.join(", ")) }
}

// ── Body rewriting ──
fn rewrite_body(body: &[u8], model_map: &HashMap<&str, &str>) -> (Bytes, Vec<String>, Option<String>, u64) {
    let Ok(mut json) = serde_json::from_slice::<Value>(body) else {
        return (Bytes::copy_from_slice(body), vec![], None, 4096);
    };
    let Some(obj) = json.as_object_mut() else {
        return (Bytes::copy_from_slice(body), vec![], None, 4096);
    };

    let mut logs = vec![];
    let mut mapped_model: Option<String> = None;

    if let Some(Value::String(model)) = obj.get("model") {
        if let Some(&mapped) = model_map.get(model.as_str()) {
            logs.push(format!("model: {} -> {}", model, mapped));
            mapped_model = Some(mapped.to_string());
            obj.insert("model".into(), Value::String(mapped.into()));
        } else {
            mapped_model = Some(model.clone());
        }
    }

    for key in &["thinking", "output_config", "temperature_presets", "service_tier", "context_management"] {
        if obj.remove(*key).is_some() {
            logs.push(format!("stripped: {}", key));
        }
    }

    // extract max_tokens for token estimation
    let max_tokens = obj.get("max_tokens").and_then(|v| v.as_u64()).unwrap_or(4096);

    let new_body = serde_json::to_vec(&json).unwrap_or_else(|_| body.to_vec());
    (Bytes::from(new_body), logs, mapped_model, max_tokens)
}

// ── Fake metrics (full fidelity) ──

/// POST to metrics/v1 — same as MetricsService.track()
async fn track(client: &HttpsClient, event: &str, user_info: &Value, values: Value) {
    let merged = {
        let mut m = json!({
            "codewiz_opencode_version": CODEWIZ_VERSION,
            "bizSource": "openCode",
        });
        if let (Some(base), Some(extra)) = (m.as_object_mut(), values.as_object()) {
            for (k, v) in extra {
                base.insert(k.clone(), v.clone());
            }
        }
        m
    };

    let payload = json!({
        "timestamp": now_ms(),
        "metricsScene": "cli",
        "metricsKey": format!("codewiz_opencode_{}", event),
        "sessionId": merged.get("sessionID").and_then(|v| v.as_str()).unwrap_or(""),
        "llmModel": merged.get("modelID").and_then(|v| v.as_str()).unwrap_or(""),
        "mainAgent": merged.get("agent").and_then(|v| v.as_str()).unwrap_or(""),
        "conversationId": merged.get("conversationId").and_then(|v| v.as_str()).unwrap_or(""),
        "userInfo": user_info.to_string(),
        "metricsValue": merged.to_string(),
    });

    let body = serde_json::to_vec(&payload).unwrap_or_default();
    let req = Request::builder()
        .method("POST").uri(METRICS_API)
        .header("content-type", "application/json")
        .body(Full::new(Bytes::from(body)));
    if let Ok(r) = req { let _ = client.request(r).await; }
}

/// POST to metrics-extended/batch — same as Cat.report()
async fn cat_report(client: &HttpsClient, metrics: Value) {
    let mut env = json!({
        "ideSeries": "cli",
        "idePlatform": "codewiz-opencode",
        "module": "cli",
        "adapterVersion": CODEWIZ_VERSION,
    });
    if let (Some(base), Some(extra)) = (env.as_object_mut(), metrics.as_object()) {
        for (k, v) in extra {
            base.insert(k.clone(), v.clone());
        }
    }
    let payload = json!({ "metrics": [env] });
    let body = serde_json::to_vec(&payload).unwrap_or_default();
    let req = Request::builder()
        .method("POST").uri(METRICS_EXTENDED_API)
        .header("content-type", "application/json")
        .body(Full::new(Bytes::from(body)));
    if let Ok(r) = req { let _ = client.request(r).await; }
}

/// POST to logs/batch — same as MetricsService.reportLog()
async fn report_log(client: &HttpsClient, msg: &str, email: &str, session_id: &str) {
    let entry = json!({
        "level": "info",
        "msg": msg,
        "ide": "codewiz-opencode",
        "module": "codewiz-opencode",
        "clientTimestamp": now_ms().to_string(),
        "traceId": "",
        "sessionId": session_id,
        "requestId": "",
        "pluginName": "cli",
        "env": {
            "userId": email,
            "pluginVersion": CODEWIZ_VERSION,
        }
    });
    let payload = serde_json::to_vec(&vec![entry]).unwrap_or_default();
    let req = Request::builder()
        .method("POST").uri(LOG_API)
        .header("content-type", "application/json")
        .body(Full::new(Bytes::from(payload)));
    if let Ok(r) = req { let _ = client.request(r).await; }
}

/// Simulate a complete codewiz CLI session for one LLM call.
/// Uses stable session_id/conversation_id from SessionState.
async fn fire_fake_session(
    client: &HttpsClient,
    model_id: &str,
    email: &str,
    user_info: &Value,
    session_id: &str,
    conversation_id: &str,
    input_tokens: u64,
    output_tokens: u64,
    cache_read: u64,
    cache_write: u64,
) {
    let message_id = uuid_v4();
    let agent = "coder";

    let base = json!({
        "sessionID": &session_id,
        "conversationId": &conversation_id,
        "agent": agent,
        "modelID": model_id,
    });

    // 1. user_input
    let mut ev = base.clone();
    ev.as_object_mut().unwrap().insert("messageID".into(), json!(&message_id));
    ev.as_object_mut().unwrap().insert("query".into(), json!("help me with this code"));
    track(client, "user_input", user_info, ev).await;

    // 2. task_conversation_message (user)
    let mut ev = base.clone();
    ev.as_object_mut().unwrap().insert("source".into(), json!("user"));
    track(client, "task_conversation_message", user_info, ev).await;

    // small delay to look realistic
    tokio::time::sleep(std::time::Duration::from_millis(50)).await;

    // 3. llm_completion
    let mut ev = base.clone();
    let obj = ev.as_object_mut().unwrap();
    obj.insert("inputTokens".into(), json!(input_tokens));
    obj.insert("outputTokens".into(), json!(output_tokens));
    obj.insert("cacheReadTokens".into(), json!(cache_read));
    obj.insert("cacheWriteTokens".into(), json!(cache_write));
    track(client, "llm_completion", user_info, ev).await;

    // 4. tool_execute (simulate a Read tool call)
    let cid = call_id();
    let tool_name = "Read";
    let mut ev = base.clone();
    let obj = ev.as_object_mut().unwrap();
    obj.insert("callID".into(), json!(&cid));
    obj.insert("tool".into(), json!(tool_name));
    track(client, "tool_execute", user_info, ev).await;

    // Cat counter for tool_execute
    cat_report(client, json!({
        "name": format!("codewiz_opencode_tool_execute"),
        "type": "counter",
        "tags": { "tool": tool_name, "sessionID": &session_id, "conversationId": &conversation_id },
        "value": 1,
    })).await;

    let tool_duration = 30 + (next_rand() % 200) as u64;
    tokio::time::sleep(std::time::Duration::from_millis(20)).await;

    // 5. tool_execute_success
    let mut ev = base.clone();
    let obj = ev.as_object_mut().unwrap();
    obj.insert("callID".into(), json!(&cid));
    obj.insert("tool".into(), json!(tool_name));
    track(client, "tool_execute_success", user_info, ev).await;

    // 6. tool_execute_duration
    let mut ev = base.clone();
    let obj = ev.as_object_mut().unwrap();
    obj.insert("callID".into(), json!(&cid));
    obj.insert("tool".into(), json!(tool_name));
    obj.insert("duration".into(), json!(tool_duration));
    obj.insert("success".into(), json!(true));
    track(client, "tool_execute_duration", user_info, ev).await;

    // Cat summary for tool_execute_duration
    cat_report(client, json!({
        "name": "codewiz_opencode_tool_execute_duration",
        "type": "summary",
        "tags": { "tool": tool_name, "sessionID": &session_id, "conversationId": &conversation_id },
        "value": tool_duration,
    })).await;

    // 7. task_conversation_message (assistant)
    let mut ev = base.clone();
    ev.as_object_mut().unwrap().insert("source".into(), json!("assistant"));
    track(client, "task_conversation_message", user_info, ev).await;

    // 8. log entry
    report_log(client, &format!("llm call completed model={}", model_id), email, &session_id).await;
}

/// Extract token usage from collected response data (works for both SSE and JSON).
fn extract_usage(data: &[u8]) -> (u64, u64, u64, u64) {
    let text = String::from_utf8_lossy(data);

    let mut input_tokens = 0u64;
    let mut output_tokens = 0u64;
    let mut cache_read = 0u64;
    let mut cache_write = 0u64;

    // Try parsing as SSE: look for "data:" lines containing usage
    for line in text.lines() {
        let line = line.trim();
        if !line.starts_with("data:") { continue; }
        let json_str = line[5..].trim();
        let Ok(v) = serde_json::from_str::<Value>(json_str) else { continue };

        // message_start has input usage
        if let Some(msg) = v.get("message") {
            if let Some(u) = msg.get("usage") {
                if let Some(n) = u.get("input_tokens").and_then(|v| v.as_u64()) { input_tokens = n; }
                if let Some(n) = u.get("cache_read_input_tokens").and_then(|v| v.as_u64()) { cache_read = n; }
                if let Some(n) = u.get("cache_creation_input_tokens").and_then(|v| v.as_u64()) { cache_write = n; }
            }
        }
        // message_delta has output usage
        if let Some(u) = v.get("usage") {
            if let Some(n) = u.get("output_tokens").and_then(|v| v.as_u64()) { output_tokens = n; }
        }
    }

    // If not SSE, try as plain JSON response
    if input_tokens == 0 && output_tokens == 0 {
        if let Ok(v) = serde_json::from_slice::<Value>(data) {
            if let Some(u) = v.get("usage") {
                input_tokens = u.get("input_tokens").and_then(|v| v.as_u64()).unwrap_or(0);
                output_tokens = u.get("output_tokens").and_then(|v| v.as_u64()).unwrap_or(0);
                cache_read = u.get("cache_read_input_tokens").and_then(|v| v.as_u64()).unwrap_or(0);
                cache_write = u.get("cache_creation_input_tokens").and_then(|v| v.as_u64()).unwrap_or(0);
            }
        }
    }

    (input_tokens, output_tokens, cache_read, cache_write)
}

type BoxBody = http_body_util::combinators::BoxBody<Bytes, Box<dyn std::error::Error + Send + Sync>>;

// ── Request handler ──
async fn handle(
    state: Arc<ProxyState>,
    req: Request<Incoming>,
) -> Result<Response<BoxBody>, Box<dyn std::error::Error + Send + Sync>> {
    let (parts, body) = req.into_parts();
    let body_bytes = body.collect().await?.to_bytes();

    let (final_body, rewrite_logs, model_id, max_tokens) = rewrite_body(&body_bytes, &state.model_map);
    for info in &rewrite_logs {
        eprintln!("[rewrite] {}", info);
    }

    let upstream_path = format!(
        "{}{}",
        state.upstream_path_prefix.trim_end_matches('/'),
        parts.uri.path_and_query().map(|pq| pq.as_str()).unwrap_or("/")
    );

    let upstream_uri: hyper::Uri = format!(
        "https://{}{}",
        state.upstream_authority, upstream_path
    ).parse()?;

    let mut builder = Request::builder().method(parts.method).uri(upstream_uri);

    for (key, val) in parts.headers.iter() {
        if key == hyper::header::HOST || key == hyper::header::CONTENT_LENGTH { continue; }
        if key == "anthropic-beta" {
            if let Ok(s) = val.to_str() {
                if let Some(filtered) = filter_beta_header(s) {
                    builder = builder.header(key, filtered);
                }
            }
            continue;
        }
        builder = builder.header(key, val);
    }

    builder = builder
        .header(hyper::header::CONTENT_LENGTH, final_body.len())
        .header("cookie", format!("{}={}", state.sso_token_key, state.sso_token))
        .header(&state.sso_token_key, &state.sso_token)
        .header("x-adapter-source", "codewiz-cli")
        .header("x-adapter-email", &state.email)
        .header("x-adapter-user-email", &state.email)
        .header("x-adapter-scenario", "codewiz-opencode-cli");

    let upstream_req = builder.body(Full::new(final_body))?;
    let resp = state.client.request(upstream_req).await?;

    let (resp_parts, resp_body) = resp.into_parts();

    // Determine if we should report metrics for this request
    let should_report = if !state.no_metrics {
        if let Some(ref _mid) = model_id {
            let mut session = state.session.lock().await;
            let n = session.bump();
            session.maybe_rotate_conversation();
            let sid = session.session_id.clone();
            let cid = session.conversation_id.clone();
            drop(session);
            if n % 3 == 0 { Some((n, sid, cid)) } else { None }
        } else { None }
    } else { None };

    if should_report.is_some() && model_id.is_some() {
        // Tee the response: stream to client while collecting for usage extraction
        let (tx, rx) = mpsc::channel::<Result<Frame<Bytes>, Box<dyn std::error::Error + Send + Sync>>>(32);
        let mid = model_id.unwrap();
        let client = state.client.clone();
        let email = state.email.clone();
        let user_info = state.user_info.clone();
        let (n, session_id, conversation_id) = should_report.unwrap();

        // Spawn task to read upstream body, forward to channel, collect for usage
        tokio::spawn(async move {
            let mut collected = BytesMut::new();
            let mut body = resp_body;
            while let Some(frame_result) = body.frame().await {
                match frame_result {
                    Ok(frame) => {
                        if let Some(data) = frame.data_ref() {
                            collected.extend_from_slice(data);
                        }
                        let _ = tx.send(Ok(frame)).await;
                    }
                    Err(e) => {
                        let _ = tx.send(Err(Box::new(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())) as Box<dyn std::error::Error + Send + Sync>)).await;
                        break;
                    }
                }
            }
            drop(tx);

            // Extract real usage from collected response
            let (input_tokens, output_tokens, cache_read, cache_write) = extract_usage(&collected);
            if input_tokens > 0 || output_tokens > 0 {
                fire_fake_session(
                    &client, &mid, &email, &user_info,
                    &session_id, &conversation_id,
                    input_tokens, output_tokens, cache_read, cache_write,
                ).await;
                eprintln!("[metrics] reported #{}: model={} in={} out={} cache_r={} cache_w={}",
                    n, mid, input_tokens, output_tokens, cache_read, cache_write);
            }
        });

        let stream = tokio_stream::wrappers::ReceiverStream::new(rx);
        let stream_body = StreamBody::new(stream);
        let boxed: BoxBody = http_body_util::BodyExt::boxed(stream_body);
        Ok(Response::from_parts(resp_parts, boxed))
    } else {
        // No metrics needed, pass through directly
        let mapped = resp_body.map_err(|e| Box::new(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())) as Box<dyn std::error::Error + Send + Sync>);
        let boxed: BoxBody = http_body_util::BodyExt::boxed(mapped);
        Ok(Response::from_parts(resp_parts, boxed))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = Args::parse();

    // seed RNG
    RNG_STATE.store(now_ms().wrapping_mul(0x517cc1b727220a95), Ordering::Relaxed);

    // auto-detect credentials from auth.json if not provided
    let creds = auto_detect_credentials();
    if args.sso_token.is_none() || args.email.is_none() {
        match &creds {
            Some(c) => {
                if args.sso_token.is_none() {
                    eprintln!("Auto-detected SSO token from auth.json");
                    args.sso_token = Some(c.sso_token.clone());
                    args.sso_token_key = c.sso_token_key.clone();
                }
                if args.email.is_none() {
                    eprintln!("Auto-detected email: {}", c.email);
                    args.email = Some(c.email.clone());
                }
            }
            None => {
                eprintln!("Error: --sso-token and --email are required (could not auto-detect from ~/.local/share/codewiz/auth.json)");
                eprintln!("Run `codewiz auth login` first, or provide --sso-token and --email manually.");
                std::process::exit(1);
            }
        }
    }

    let sso_token = args.sso_token.clone().unwrap();
    let email = args.email.clone().unwrap();

    let upstream_url: hyper::Uri = args.upstream.parse()?;
    let authority = upstream_url.authority().expect("upstream must have authority").to_string();
    let path_prefix = upstream_url.path().to_string();

    let https = HttpsConnector::new();
    let client = Client::builder(TokioExecutor::new()).build(https);

    let model_map = build_model_map();
    eprintln!("Model mappings:");
    let mut entries: Vec<_> = model_map.iter().collect();
    entries.sort_by_key(|(k, _)| *k);
    for (from, to) in &entries { eprintln!("  {} -> {}", from, to); }

    // extract user info from token for metrics
    let user_info = extract_user_info(&read_token_from_auth_json().unwrap_or_default());

    let state = Arc::new(ProxyState {
        client,
        upstream_authority: authority,
        upstream_path_prefix: path_prefix,
        sso_token,
        sso_token_key: args.sso_token_key.clone(),
        email,
        model_map,
        user_info,
        no_metrics: args.no_metrics,
        session: tokio::sync::Mutex::new(SessionState::new()),
    });

    let addr = SocketAddr::from(([127, 0, 0, 1], args.port));
    let listener = TcpListener::bind(addr).await?;

    eprintln!();
    eprintln!("claude-proxy listening on http://{}", addr);
    eprintln!("  upstream : {}", args.upstream);
    eprintln!("  email    : {}", state.email);
    eprintln!("  metrics  : {}", if args.no_metrics { "disabled" } else { "enabled (fake)" });
    eprintln!();
    eprintln!("Export for Claude Code:");
    eprintln!("  export ANTHROPIC_BASE_URL=http://127.0.0.1:{}", args.port);
    eprintln!("  export ANTHROPIC_API_KEY=dummy");

    loop {
        let (stream, _) = listener.accept().await?;
        let state = state.clone();
        let io = hyper_util::rt::TokioIo::new(stream);
        tokio::spawn(async move {
            if let Err(e) = http1::Builder::new()
                .serve_connection(io, service_fn(|req| handle(state.clone(), req)))
                .await
            {
                eprintln!("connection error: {}", e);
            }
        });
    }
}

/// Try to read the codewiz auth token from the standard auth.json location.
fn read_token_from_auth_json() -> Option<String> {
    let home = std::env::var("HOME").unwrap_or_else(|_| "/root".into());
    let path = format!("{}/.local/share/codewiz/auth.json", home);
    let content = std::fs::read_to_string(&path).ok()?;
    let json: Value = serde_json::from_str(&content).ok()?;
    // find the first wellknown entry
    for (_key, val) in json.as_object()? {
        if val.get("type")?.as_str()? == "wellknown" {
            return val.get("token")?.as_str().map(|s| s.to_string());
        }
    }
    None
}
